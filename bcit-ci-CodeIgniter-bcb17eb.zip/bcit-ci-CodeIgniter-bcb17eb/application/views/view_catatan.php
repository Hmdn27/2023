<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>CATATAN</h1>

    <table border='1'>
        <tr>
            <th>ID PERJALANAN</th>
            <th>TANGGAL</th>
            <th>WAKTU</th>
            <th>LOKASI</th>
            <th>SUHU TUBUH</th>
            <th>NIK AKUN</th>
        </tr>
        <?php foreach ($query as $query) { ?>
            <tr>
                <td><?=$query->id_perjalanan ?></td>
                <td><?=$query->tanggal ?></td>
                <td><?=$query->waktu ?></td>
                <td><?=$query->lokasi ?></td>
                <td><?=$query->suhutubuh ?></td>
                <td><?=$query->nik_akun ?></td>
            </tr>
            <?php } ?>
    </table>
</body>
</html>