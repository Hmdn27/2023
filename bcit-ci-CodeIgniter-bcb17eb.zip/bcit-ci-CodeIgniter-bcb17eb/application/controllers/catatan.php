<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class catatan extends CI_Controller {

	public function Hamdan()
	{
		$data['query'] = $this->db->get('isidata')->result();
        

        // foreach ($query as $query){
        // echo $query[0]->idbarang;    
        // }
        $this->load->view('view_catatan', $data);
        
         }
	}