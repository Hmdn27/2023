<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class signup extends CI_Controller {

	public function index()
	{
		echo ('Halaman Daftar');
	}
	public function home(){
		echo "ini home";
	}
	
	public function login(){
		echo "ini adalah login";
	}
	
}

