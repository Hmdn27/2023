<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class hello extends CI_Controller {

	public function data($data)
	{
		echo $data;
	}

    public function tampil(){
        $data['judul'] = "Halaman Tampil";
        $data['deskripsi'] = "Ini Deskripsi";

        $this->load->view('tampil', $data);
    }
}
