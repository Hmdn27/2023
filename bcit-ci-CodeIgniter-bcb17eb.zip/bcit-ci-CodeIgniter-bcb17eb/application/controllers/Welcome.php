<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function home(){
		echo "ini home";
	}
	
	public function login(){
		$data['jurusan'] = "RPL";
		$data['kelas'] = "12)";
		$this->load->view('view_login', $data);
	}
	
}

